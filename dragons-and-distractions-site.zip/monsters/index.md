# 🗺️ Monster Index

Welcome to the Bestiary.

Each monster represents a real executive function challenge — named, described, and disarmed with humor, science, and ritual.

- [The Slumber Troll](slumber-troll.md)
- [The Task Hydra](task-hydra.md)
- [The Dopamine Goblin](dopamine-goblin.md)
- [The Temporal Shark](temporal-shark.md)

More monsters await...
